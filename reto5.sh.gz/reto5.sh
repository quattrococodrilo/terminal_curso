#!/bin/bash
# Author: Fernando Cruz
# Email: quattrococodrilo@gmail.com

# Modificar el archivo utilityHost.sh para escribir 
# la información solicitada a un archivo de log cuyo 
# nombre será log donde yyyy representa el año, 
# MM el mes, DD el día, HH la hora, mm los minutos y 
# SS los segundos.

now=$(date +"%Y%m%d%H%M%S")

echo $1 >> log


