#!/bin/bash

#Programa para revisar la declaración de varables

echo "Variable del script anterior: $name"

