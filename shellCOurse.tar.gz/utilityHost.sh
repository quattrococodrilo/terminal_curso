#!/bin/bash

# Author: Luis Fernando Cruz Carrillo

option=$1
result=$((option * option))

echo "The result is: $result"
