#!/bin/bash
# Programa para ejemplificar el empaquetamiento con el comando tar 
# Author: Fernando Cruz - quattrococodrilo

echo "--------------------------------"
echo "Empaquetar todos los scripts tar"
echo "--------------------------------"

tar -cvf shellCOurse.tar *.sh
