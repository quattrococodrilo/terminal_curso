#!/bin/basg
# Download a file

exec curl $1 -o $2
